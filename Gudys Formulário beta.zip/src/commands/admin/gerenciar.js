const { ApplicationCommandType, EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { JsonDatabase } = require("wio.db");
const db = new JsonDatabase({databasePath:"./src/database/config.json"});
const {owner} = require("../../../token.json");

module.exports = {
    name: "panelada",
    description: "Gerencie o Sistema de Perguntas",
    type: ApplicationCommandType.ChatInput,
    run: async(client, interaction) => {
        const userid = interaction.user.id;
        if(userid !== owner) return interaction.reply({content: `<:emoji_4:1324735169453621290> | Você não tem permissão de usar o comando panelada!`, ephemeral: true});
        
        interaction.reply({
            embeds: [
                new EmbedBuilder()
                .setTitle(`Sistrma de Configuração`)
                .setDescription(`Olá ***${interaction.user.username}*** seja bem-vindo ao painel do bot de perguntas, escolha qual das funções você deseja gerenciar.`)
                .setColor("Random")
                .setFooter({text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL()})
            ],
            components: [
                new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setCustomId(`${userid}_gerenciarperguntas`)
                    .setLabel("Perguntas")
                    .setStyle(1)
                    .setEmoji("<:duvida_Csync:1323708142340538419>"),
                    new ButtonBuilder()
                    .setCustomId(`${userid}_gerenciarcategoria`)
                    .setLabel("Categoria")
                    .setStyle(1)
                    .setEmoji("<:conversa_StorM:1324733240656920621>"),
                    new ButtonBuilder()
                    .setCustomId(`${userid}_gerenciarlogs`)
                    .setLabel("Logs")
                    .setStyle(1)
                    .setEmoji("<:1273829389662158928:1324732528866754746>"),
                    new ButtonBuilder()
                    .setCustomId(`${userid}_gerenciarrole`)
                    .setLabel("Cargo")
                    .setStyle(1)
                    .setEmoji("<:backup_wk:1324732854378299517>"),
                )
            ],
            ephemeral: true
        });
    }
}
