const Discord = require("discord.js");
module.exports = {
    name: "lock",
    description: "Tranque um canal",
    type: Discord.ApplicationCommandType.ChatInput,

    run: async(client, interaction) => {
        // Verifica se o usuário tem a permissão de Gerenciar Canais
        if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageChannels)) {
            return interaction.reply({ content: `❌ | Você não possui a permissão \`Gerenciar Canais\` para usar este comando.`, ephemeral: true });
        }

        // Cria um embed informando que o canal foi trancado
        let embed = new Discord.EmbedBuilder()
            .setTitle("<:cadeado:1290720932603891918> Canal Trancado")
            .setColor(0x000000) // Cor preta
            .addFields({ name: `Este canal foi trancado.`, value: `🔒 Trancado por: ${interaction.user}` });

        try {
            // Modifica as permissões do canal para que membros não possam mais enviar mensagens
            await interaction.channel.permissionOverwrites.edit(interaction.guild.id, { SendMessages: false });

            // Responde à interação com o embed
            await interaction.reply({ embeds: [embed], ephemeral: false });

        } catch (error) {
            console.log(error);
            // Se ocorrer algum erro, edita a resposta da interação para informar o erro
            interaction.reply({ content: `❌ | Ops, algo deu errado ao tentar trancar este canal.`, ephemeral: true });
        }
    }    
};
