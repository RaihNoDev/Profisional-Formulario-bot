const { ApplicationCommandType, EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { JsonDatabase } = require("wio.db");
const db = new JsonDatabase({databasePath:"./src/database/config.json"});
const {owner} = require("../../../token.json");

module.exports = {
    name:"painel-perguntas",
    description:"Envie o Painel de Perguntas",
    type: ApplicationCommandType.ChatInput,
    run: async(client, interaction) => {
        const userid = interaction.user.id;
        if(userid !== owner) return interaction.reply({content:`<:emoji_4:1324735169453621290> | Você não tem permissão de gerenciar!`, ephemeral:true});
        interaction.channel.send({
            embeds:[
                new EmbedBuilder()
                .setTitle(`( 💜 ) Formulario Gudys`)
                .setDescription(`**<:userJEFF:1323707995846344887> REQUISITOS**\n- Abrir com responsabilidade de ser um poster\n- Olha as perguntas com atenção e responda certo as perguntas\n- Ser abrir o formulário e não responder vai levar mute ser manda coisas aleatória mute também.`)
                .setColor("812eed")
                .setImage("https://cdn.discordapp.com/attachments/1321180981696266300/1321688932588589076/1734574275-banner.png?ex=676e263d&is=676cd4bd&hm=42a3d8ed86820d3bdcb975854f7cf2d508c53036fa94ffec9beaa11d774670f7&")
                .setFooter({text:`Todos os Direitos Reservados`, iconURL: interaction.guild.iconURL()})
                .setTimestamp()
            ],
            components: [
                new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setCustomId(`formulario`)
                    .setLabel("Abrir Formulário")
                    .setStyle(1)
                    .setEmoji("<:emoji_19:1324734337978990683>")
                )
            ]
        });
        interaction.reply({content:`<:emoji_3:1324735226475188338> | Painel Enviado com sucesso!`, ephemeral:true});
    }}