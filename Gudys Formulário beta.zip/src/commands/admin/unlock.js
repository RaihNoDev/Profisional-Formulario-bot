const Discord = require("discord.js");

module.exports = {
    name: "unlock", 
    description: "Abra um canal.",
    type: Discord.ApplicationCommandType.ChatInput,
    
    run: async(client, interaction) => {
        // Verifica se o usuário tem a permissão de Gerenciar Canais
        if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageChannels)) {
            return interaction.reply({ content: `❌ | Você não possui a permissão \`Gerenciar Canais\` para usar este comando.`, ephemeral: true });
        }

        // Cria um embed informando que o canal foi destrancado
        let destrancar = new Discord.EmbedBuilder()
            .setTitle("<:loadwack:1290721080767549450> Canal Destrancado")
            .addFields({ name: `Esse canal foi destrancado.`, value: `🔓 Destrancado por: ${interaction.user}` })
            .setColor(0x000000); // Cor preta

        try {
            // Modifica as permissões do canal para permitir que membros enviem mensagens novamente
            await interaction.channel.permissionOverwrites.edit(interaction.guild.id, { SendMessages: true });

            // Responde à interação com o embed
            await interaction.reply({ embeds: [destrancar], ephemeral: false });

        } catch (error) {
            console.log(error);
            // Se ocorrer algum erro, edita a resposta da interação para informar o erro
            interaction.reply({ content: `❌ | Ops, algo deu errado ao tentar destrancar este chat.`, ephemeral: true });
        }
    }        
};
