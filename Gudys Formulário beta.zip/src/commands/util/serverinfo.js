const Discord = require("discord.js");
const moment = require("moment");

module.exports = {
    name: "serverinfo",
    description: "Veja as informações do servidor",
    type: Discord.ApplicationCommandType.ChatInput,
    run: async (client, interaction) => {
        const { guild } = interaction;
        const membros = guild.memberCount;
        const bots = guild.members.cache.filter(member => member.user.bot).size; // Contagem de bots
        const dono = await guild.fetchOwner();
        const dataCriacao = moment(guild.createdAt).locale('pt-br').format('LLLL'); // Data de criação do servidor em PT-BR

        // Construção da mensagem embed
        const embed = {
            color: 0x0099ff,
            description: `**Informações do(a) > ${guild.name}**`,
            thumbnail: { url: guild.iconURL({ dynamic: true, format: "png", size: 4096 }) }, // Adiciona a logo do servidor
            fields: [
                { name: "ID do Servidor", value: `\`${guild.id}\`` },
                { name: "Criado em", value: `\`${dataCriacao}\``, inline: true },
                { name: "Dono do Servidor", value: `\`${dono.user.tag}\n(<@${dono.id}>)\``, inline: true },
                { name: "Membros", value: `Total: \`${membros}\`\nBots: \`${bots}\``, inline: true },
            ]
        };

        await interaction.reply({ embeds: [embed], ephemeral: true }); // Aqui, o ephemeral está como true
    }
};
