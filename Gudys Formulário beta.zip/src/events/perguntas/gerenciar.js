const { ActionRowBuilder, StringSelectMenuBuilder, ChannelSelectMenuBuilder, ChannelType, EmbedBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, RoleSelectMenuBuilder } = require("discord.js");
const { JsonDatabase } = require("wio.db");
const db = new JsonDatabase({databasePath:"./src/database/config.json"});
const {owner} = require("../../../token.json");


module.exports = {
    name:"interactionCreate", 
    run: async( interaction, client) => {
        const customId = interaction.customId;
        if(!customId) return;
        const userid = customId.split("_")[0];
        if(userid !== interaction.user.id) return;

        if(customId.endsWith("_gerenciarcategoria")) {
            interaction.update({
                embeds:[],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ChannelSelectMenuBuilder()
                        .setCustomId(`${userid}_selectcategory`)
                        .setChannelTypes(ChannelType.GuildCategory)
                        .setMaxValues(1)
                        .setPlaceholder("Escolha a Categoria que será aberto.")
                    )
                ]
            });
        }
        if(customId.endsWith("_selectcategory")) {
            const id = interaction.values[0];
            await db.set("category", id);
            gerenciar();
        }


        if(customId.endsWith("_gerenciarlogs")) {
            interaction.update({
                embeds:[],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ChannelSelectMenuBuilder()
                        .setCustomId(`${userid}_selectlogs`)
                        .setChannelTypes(ChannelType.GuildText)
                        .setMaxValues(1)
                        .setPlaceholder("Escolha o Canal de Logs que será enviado.")
                    )
                ]
            });
        }
        if(customId.endsWith("_selectlogs")) {
            const id = interaction.values[0];
            await db.set("logs", id);
            gerenciar();
        }

        if(customId.endsWith("_voltar")) {
            gerenciar();
        }
        if(customId.endsWith("_gerenciarperguntas")) {
            perguntas();
        }
        if(customId.endsWith("_addpergunta")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_addperguntamodal`)
            .setTitle("✅ - Adicionar Pergunta");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setStyle(2)
            .setLabel("Coloque a pergunta:")
            .setPlaceholder("Ex: Quantos anos você tem?")
            .setMaxLength(2000)
            .setRequired(true)
            .setMinLength(3);

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }
        if(customId.endsWith("_addperguntamodal")) {
            const text = interaction.fields.getTextInputValue("text");
            await db.push("perguntas", text);
            perguntas();
        }
        if(customId.endsWith("_removerpergunta")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_removerperguntamodal`)
            .setTitle("❌ - Remover Pergunta");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setStyle(1)
            .setLabel("Coloque o numero da pergunta:")
            .setPlaceholder("1")
            .setMaxLength(4)
            .setRequired(true)

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }
        if(customId.endsWith("_removerperguntamodal")) {
            const text = interaction.fields.getTextInputValue("text");
            if(isNaN(text)) return interaction.reply({content:`Coloque apenas numeros!`, ephemeral:true});
            const a = await db.get(`perguntas`);
            a.splice(Number(text), 1)[0]; 
            await db.set(`perguntas`, a);
            perguntas();
        }
        if(customId.endsWith("_gerenciarrole")) {
            interaction.update({
                embeds:[],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new RoleSelectMenuBuilder()
                        .setCustomId(`${userid}_roleselect`)
                        .setPlaceholder("Escolha o cargo dê quem será aprovado")
                        .setMaxValues(1)
                    )
                ]
            });
        }
        if(customId.endsWith("_roleselect")) {
            await db.set("role", interaction.values[0]);
            gerenciar();
        }
        async function perguntas() {
            const pergunt = await db.get("perguntas");
            let msg = "";
            if(pergunt.length > 0) {
                pergunt.map((rs, index) => {
                    msg += `__${index}°__ - ${rs}\n`;
                });
            } else {
                msg = "`Não foi encontrado Nenhuma Pergunta.`"
            }
            interaction.update({
                embeds:[
                    new EmbedBuilder()
                    .setTitle(`| Perguntas`)
                    .setDescription(`**Todas as Perguntas:**\n\n${msg}`)
                    .setColor("Random")
                    .setTimestamp()
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_addpergunta`)
                        .setLabel("Adicionar Pergunta")
                        .setStyle(3)
                        .setEmoji("<:emoji_15:1324733752773050368>"),
                        new ButtonBuilder()
                        .setCustomId(`${userid}_removerpergunta`)
                        .setLabel("Remover Pergunta")
                        .setStyle(4)
                        .setEmoji("<:emoji_16:1324733875712299028>"),
                        new ButtonBuilder()
                        .setCustomId(`${userid}_voltar`)
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji("<:emoji_27:1324734802556878930>"),
                    )
                ]
            })

        }
        function gerenciar() {
            interaction.update({
                embeds:[
                    new EmbedBuilder()
                    .setTitle(`Gerenciamento`)
                    .setDescription(`Olá ***${interaction.user.username}*** seja bem vindo ao painel de gerenciamento de perguntas, escolha qual das funções você deseja gerenciar.`)
                    .setColor("Random")
                    .setFooter({text:`${interaction.guild.name}`, iconURL: interaction.guild.iconURL()})
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_gerenciarperguntas`)
                        .setLabel("Perguntas")
                        .setStyle(1)
                        .setEmoji("<:duvida_Csync:1323708142340538419>"),
                        new ButtonBuilder()
                        .setCustomId(`${userid}_gerenciarcategoria`)
                        .setLabel("Categoria")
                        .setStyle(1)
                        .setEmoji("<:conversa_StorM:1324733240656920621>"),
                        new ButtonBuilder()
                        .setCustomId(`${userid}_gerenciarlogs`)
                        .setLabel("Logs")
                        .setStyle(1)
                        .setEmoji("<:1273829389662158928:1324732528866754746>"),
                        new ButtonBuilder()
                        .setCustomId(`${userid}_gerenciarrole`)
                        .setLabel("Cargo")
                        .setStyle(1)
                        .setEmoji("<:backup_wk:1324732854378299517>"),
                    )
                ]
            })
        }
    }
}