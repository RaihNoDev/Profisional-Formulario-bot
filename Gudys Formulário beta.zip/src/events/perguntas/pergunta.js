const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder, ButtonBuilder } = require("discord.js");
const { JsonDatabase } = require("wio.db");
const db = new JsonDatabase({ databasePath: "./src/database/config.json" });

module.exports = {
    name: "interactionCreate",
    run: async (interaction, client) => {
        if (interaction.isButton() && interaction.customId === "formulario") {
            const perguntas = await db.get("perguntas") || [];
            if (perguntas.length === 0) {
                return interaction.reply({
                    content: "⚠️ Nenhuma pergunta configurada no sistema.",
                    ephemeral: true,
                });
            }

            // Criar o Modal
            const modal = new ModalBuilder()
                .setCustomId("formulario_modal")
                .setTitle("Formulário de Alistamento");

            // Adicionar campos de perguntas ao Modal
            perguntas.forEach((pergunta, index) => {
                const input = new TextInputBuilder()
                    .setCustomId(`pergunta_${index}`)
                    .setLabel(pergunta)
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(true);

                const actionRow = new ActionRowBuilder().addComponents(input);
                modal.addComponents(actionRow);
            });

            // Mostrar o Modal
            await interaction.showModal(modal);
        }

        // Processar Respostas do Modal
        if (interaction.isModalSubmit() && interaction.customId === "formulario_modal") {
            const perguntas = await db.get("perguntas") || [];
            let todasRespostas = "";

            perguntas.forEach((pergunta, index) => {
                const resposta = interaction.fields.getTextInputValue(`pergunta_${index}`);
                todasRespostas += `**Pergunta:** ${pergunta}\n**Resposta:** ${resposta}\n\n`;
            });

            // Enviar Respostas para o Canal de Logs
            const logs = interaction.client.channels.cache.get(await db.get("logs"));
            if (logs) {
                logs.send({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle("Resultado do Formulário")
                            .setDescription(
                                `**Usuário:** ${interaction.user}\n**ID:** \`${interaction.user.id}\`\n\n${todasRespostas}`
                            )
                            .setColor("Random")
                            .setFooter({ text: "Todos os Direitos Reservados", iconURL: interaction.guild.iconURL() })
                            .setTimestamp(),
                    ],
                    components: [
                        new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setCustomId(`${interaction.user.id}_aprovado`)
                                .setLabel("Aprovar")
                                .setStyle(2)
                                .setEmoji("✅"),
                            new ButtonBuilder()
                                .setCustomId(`${interaction.user.id}_reprovado`)
                                .setLabel("Reprovar")
                                .setStyle(2)
                                .setEmoji("❌")
                        ),
                    ],
                });
            }

            // Responder ao Usuário
            await interaction.reply({
                content: "✅ Suas respostas foram enviadas para a equipe de recrutamento. Obrigado!",
                ephemeral: true,
            });
        }

        // Botões de Aprovar/Reprovar
        if (interaction.isButton()) {
            if (interaction.customId.endsWith("_aprovado")) {
                await interaction.update({
                    components: [
                        new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setCustomId(`${interaction.user.id}_aprovado`)
                                .setDisabled(true)
                                .setLabel("Aprovar")
                                .setStyle(2)
                                .setEmoji("✅"),
                            new ButtonBuilder()
                                .setCustomId(`${interaction.user.id}_reprovado`)
                                .setDisabled(true)
                                .setLabel("Reprovar")
                                .setStyle(2)
                                .setEmoji("❌")
                        ),
                    ],
                });

                const user = interaction.client.users.cache.get(interaction.customId.split("_")[0]);
                if (user) {
                    user.send({
                        embeds: [
                            new EmbedBuilder()
                                .setTitle("Resultado")
                                .setDescription(
                                    `👋 Olá ${user}, você foi aprovado no alistamento! Entre em contato com um recrutador.`
                                )
                                .setColor("Green")
                                .setFooter({ text: "Todos os Direitos Reservados", iconURL: interaction.guild.iconURL() })
                                .setTimestamp()
                        ],
                    }).catch(() => {});
                }
            }

            if (interaction.customId.endsWith("_reprovado")) {
                await interaction.update({
                    components: [
                        new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setCustomId(`${interaction.user.id}_aprovado`)
                                .setDisabled(true)
                                .setLabel("Aprovar")
                                .setStyle(2)
                                .setEmoji("✅"),
                            new ButtonBuilder()
                                .setCustomId(`${interaction.user.id}_reprovado`)
                                .setDisabled(true)
                                .setLabel("Reprovar")
                                .setStyle(2)
                                .setEmoji("❌")
                        ),
                    ],
                });

                const user = interaction.client.users.cache.get(interaction.customId.split("_")[0]);
                if (user) {
                    user.send({
                        embeds: [
                            new EmbedBuilder()
                                .setTitle("Resultado")
                                .setDescription(
                                    `👋 Olá ${user}, infelizmente você foi reprovado no alistamento. Tente novamente no futuro!`
                                )
                                .setColor("Red")
                                .setFooter({ text: "Todos os Direitos Reservados", iconURL: interaction.guild.iconURL() })
                                .setTimestamp()
                        ],
                    }).catch(() => {});
                }
            }
        }
    },
};