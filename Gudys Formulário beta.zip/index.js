const {Client , GatewayIntentBits,Collection, Partials } = require("discord.js");
console.clear()

const client = new Client({
  intents: Object.keys(GatewayIntentBits),
  partials: Object.keys(Partials)
});

module.exports = client;
client.slashCommands = new Collection();
const {token} = require("./token.json");
client.login(token);


const evento = require("./src/handler/Events");
evento.run(client);
require("./src/handler/index")(client);

const {ActivityType } = require('discord.js');

const activities = [
    { name: 'Nyno | Programer?', type: ActivityType.Playing },
    { name: 'Gudys Community', type: ActivityType.Watching },
    { name: 'Faca seu Formulário', type: ActivityType.Streaming, url: 'https://www.twitch.tv/discord' },
];

client.once('ready', () => {
    console.log(`Bot está online como ${client.user.tag}`);
    
    // Troca de atividade a cada 1 minuto (60000 milissegundos)
    setInterval(() => {
        const randomActivity = activities[Math.floor(Math.random() * activities.length)];
        client.user.setActivity(randomActivity);
        
    }, 50000); // 60000 ms = 1 minuto
});

// Substitua 'SEU_TOKEN_AQUI' pelo token do seu bot
client.login('');
